Matthew Michael Sherlin
Homework 2 for Systems Programming

Makefile runs as follows:
'make run' to create executables for each function. It will create three executables under the names 'concat', 'copy', 'compare'
Use './name' in order to run each function.

'make clean' in order to clean up all of the executable files. This will delete the executables and nothing else.
